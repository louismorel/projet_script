let cs = document.getElementById("cv");
let ctx = cs.getContext("2d");

// Déclaration de variables globales pour gestion du temps et des collisions avec les lutins.
var timeLeft = 210;

let gameStopped = false;

let lastHit = new Date();

let isStopped = false;
let lastStop;

//Déclaration des variables audio et ajustement des volumes
let backgroundMusic = new Audio("../ressources/Silent-night.mp3");
backgroundMusic.volume = 0.2;
let hohoho = new Audio("../ressources/Emotisound-hoho.mp3");
hohoho.volume = 1;
let elfLaugh = new Audio("../ressources/sf-laugh-elf-creature-01.mp3");
elfLaugh.volume = 1;
let loose = new Audio("../ressources/SoundOfSilence.mp3");
loose.volume = 0.8;
let grelot = new Audio("../ressources/grelot.mp3");
grelot.volume = 1;
let victoryMusic = new Audio("../ressources/victoryMusic.mp3");
victoryMusic.volume = 0.7;

// Fonctions permettant la lecture ou l'arrêt de l'audio.
let playBackGroundMusic = function(){
	if(!gameStopped)
		backgroundMusic.play();
};
let stopBackGroundMusic = function(){
	backgroundMusic.volume = 0;
};

let playHohoho = function(){
	hohoho.play();
};
let stopHohoho = function(){
	hohoho.volume = 0;
};


let playElfLaugh = function(){
	elfLaugh.play();
};
let stopElfLaugh = function(){
	elfLaugh.volume = 0;
};

let playLooseMusic = function(){
	loose.play();
};

let playGrelot = function(){
	grelot.play();
};
let stopGrelot = function(){
	grelot.volume = 0;
};

let playVictoryMusic = function(){
	victoryMusic.play();
};

//Variable convertissant la flèche utilisée en valeurs numériques pour la découpe de l'image du père Noël.
let direction = {
	"ArrowRight": 110,
	"ArrowLeft": 302,
	"ArrowUp": 5,
	"ArrowDown": 205
};
//Valeur par defaut de la direction, le père Noël est face au joueur.
let sySanta = direction["ArrowDown"];
let sxSanta = 0;
//Création de la variable de type père Noël
let santa = new PereNoel();

//Différents listes permettant de stocker les sapins, lutins et boules de Noël présents.
let listTree = new Array();
let listElf = new Array();
let listBall = new Array();

//Permet de décrémenter la variable stockant le temps restant (fonction appelée toutes les secondes).
let decreaseTime = function(){
	if(!gameStopped){
		timeLeft-=1;
	}
};

//Fonction permettant d'obtenir un effet visuel de marche du pere noel. (Déplacement dans l'image donnée pour obtenir ce rendu).
let walkSanta = function () {
	if(sxSanta===142)
		sxSanta=0;
	else
		sxSanta+=71;
};

//Fonction permettant le déplacement des lutins (dont la vitesse accélérée à la fin).
let walkElf =function(){
	let speed = 1;
	//S'il reste moins de 20 sec on double la vitesse.
	if(timeLeft<=20)
		speed = 2;
	//Si les lutins ne sont pas arrêtés à cause d'une boule de noël.
	if(!isStopped){
		//On lit tous les éléments de type Elf dans la liste
		for(let i=0 ; i<listElf.length ; i++){
			//Si le lutin n'a pas changé de direction depuis plus de 3 sec.
			if(listElf[i].getTime()>3000){
				//On tire au hasard une nouvelle direction (X ou Y puis + ou -).
				let directionXY = Math.round(Math.random());
				let directionPlusMinus = Math.round(Math.random());
				listElf[i].changeDirection(directionXY, directionPlusMinus);
				listElf[i].changeTime()
			}
			//En fonction de sa direction on change sa position
			if(listElf[i].directionXY===0){
				if(listElf[i].directionPlusMinus===0)
					listElf[i].x += speed;
				else
					listElf[i].x -= speed;
			}
			else{
				if(listElf[i].directionPlusMinus===0)
					listElf[i].y += speed;
				else
					listElf[i].y -= speed;
			}	
			
			//Si le lutin arrive sur le bord de l'image on l'envoie sur l'autre bord.
			if(listElf[i].x > 775){
				listElf[i].x = 0;
			}else if(listElf[i].x < 0){
				listElf[i].x = 775;
			}else if(listElf[i].y > 570){
				listElf[i].y = 0;
			}else if(listElf[i].y < 0){
				listElf[i].y = 570;
			}		
		}
	}
};

//Fonctions de dessin

let drawSanta = function () {
	ctx.drawImage(pereNoel, sxSanta, sySanta, 70, 100, santa.x, santa.y, 70, 100);
};

let drawFond = function(){
	ctx.drawImage(fond, 0, 0,800,600);
};

let drawTree = function(){
	for(let i = 0; i<listTree.length;i++){
		//Si le sapin est décoré.
		if(!(listTree[i].isDecorated)){			
			//Si le sapin a déjà été trouvé.
			if(!listTree[i].isDone)
				ctx.drawImage(sapin,listTree[i].x,listTree[i].y);
			else
				ctx.drawImage(sapinGift,listTree[i].x,listTree[i].y);
		}
		else{			
			//Si le sapin a déjà été trouvé.
			if(!listTree[i].isDone)
				ctx.drawImage(sapinDecore,listTree[i].x,listTree[i].y);
			else
				ctx.drawImage(sapinDecoreGift,listTree[i].x,listTree[i].y);
		}
	}
};

let drawElf = function(){
	for(let i = 0; i<listElf.length;i++){
		//En fonction de la direction des lutin la partie choisie de l'image n'est pas la même.
		if(listElf[i].directionXY===0){
			if(listElf[i].directionPlusMinus===0){
				ctx.drawImage(elfIm, 3, 64, 26, 31, listElf[i].x, listElf[i].y, 26, 31);
			}else{
				ctx.drawImage(elfIm, 3, 32, 26, 31, listElf[i].x, listElf[i].y, 26, 31);
			}
		}
		else{
			if(listElf[i].directionPlusMinus===1){
				ctx.drawImage(elfIm, 3, 96, 26, 31, listElf[i].x, listElf[i].y, 26, 31);
			}else{
				ctx.drawImage(elfIm, 3, 0, 26, 31, listElf[i].x, listElf[i].y, 26, 31);
			}
		}
	}
};

let drawBall = function(){
	if(listBall.length>0){
		for(let i = 0; i<listBall.length ; i++)
			ctx.drawImage(ballIm, 0, 0, 41, 50, listBall[i].x, listBall[i].y, 41, 50);
	}
};

let drawMenu = function(){
	ctx.drawImage(menu, 0, 0, 800, 100, 0, 550, 800, 100);
};

//Fonction permettant d'écrire dans le menu.
let write = function(){
	ctx.font = "30px Verdana";
	ctx.fillStyle = "#FFFFFF";
	//On convertit le temps restant (en s) en mm:ss.
	let min = Math.floor(timeLeft/60);
	let sec = (timeLeft - min*60);
	
	//Permet d'eviter d'affiche 3:1, on préfère 3:01.
	if(sec<10)
		sec = "0"+sec;
	ctx.fillText(min+":"+sec, 55, 585);
	ctx.fillText(santa.money, 385, 585);
	ctx.fillText(santa.gift, 713, 585);
};

//Si le jeux n'est pas arrêté on appelle toutes les fonctions de dessin.
let draw = function(){
	if(!gameStopped){
		drawFond();
		drawTree();
		drawElf();
		drawBall();
		drawSanta();
		drawMenu();
		write();
	}
};

//Ajout d'un nouvel arbre dans la liste dédiée.
let createTree = function(){
	let tree = new Sapin();
	listTree.push(tree);
};

//Suppression des arbres dont le temps limite est dépassé.
let deleteTree = function(){
	for(let i = 0; i<listTree.length;i++){	
		if(listTree[i].isDecorated && listTree[i].getTime() >= 9998){
			listTree.splice(i,1);
		}
		else if(!(listTree[i].isDecorated) && listTree[i].getTime() >= 19998){
			listTree.splice(i,1);
		}
	}
};

//Création des lutins avec une position aléatoire + direction aléatoire.
let createElfs = function(tree){
	let elf = new Elf(Math.floor((Math.random()*740)),Math.floor((Math.random()*520)),Math.round(Math.random()),Math.round(Math.random()));
	//Créer 1 ou 2 lutin en fonction du sapin trouvé par le pere noel.
	if(!tree.isDecorated){
		listElf.push(elf);
	}
	else{
		listElf.push(elf);
		elf = new Elf(Math.floor((Math.random()*740)),Math.floor((Math.random()*520)),Math.round(Math.random()),Math.round(Math.random()));
		listElf.push(elf);
	}
	
};

//Création des boules de noël à des postions aléatoires aux instants demandés en consigne.
let createBall = function(){
	if(timeLeft===140 || timeLeft===60){
		let ball = new Ball(Math.floor((Math.random()*740)),Math.floor((Math.random()*520)));
		listBall.push(ball);
	}
};

//Suppression des boules de noël trouvées.
let deleteBall = function(x, y){
	for(let i = 0; i<listBall.length;i++){	
		if(listBall[i].x===x && listBall[i].y === y){
			listBall.splice(i,1);
		}
	}
};

//Quand le pere noel recontre un arbre.
let hitTree = function(){
	for(let i = 0; i<listTree.length ; i++){
		//Test pour voir si le pere noel marche sur un sapin.
		if(((santa.x + 55 >= listTree[i].x) && (santa.y + 80 >= listTree[i].y)) && ((santa.x <= listTree[i].x + 45) && (santa.y <= listTree[i].y + 60))){
			//Si le sapin n'a pas déjà été trouvé on joue la musique, on crée un lutin, on déclare ce sapin comme trouvé et on dépose des cadeaux.
			if(!listTree[i].isDone){
				playHohoho();
				createElfs(listTree[i]);
				listTree[i].found();
				santa.dropGifts(listTree[i]);
			}			
		}
	}
};

//Quand le pere noel recontre un lutin.
let hitElf = function(){
	for(let i = 0; i<listElf.length ; i++){
		//Test pour voir si le pere noel marche sur un lutin.
		if(((santa.x + 55 >= listElf[i].x) && (santa.y + 75 >= listElf[i].y)) && ((santa.x <= listElf[i].x + 23) && (santa.y <= listElf[i].y + 30))){
			//Si la dernière collision avec un lutin a eu lieu il y a plus de 3 sec alors on joue la musique et on perd de l'argent.
			if(lastHit===null || Math.round(new Date()-lastHit > 3000)){
				//On note l'instant de la collision.
				lastHit = new Date();
				playElfLaugh();
				santa.dropMoney();
			}			
		}
	}
};

//Quand le pere noel recontre une boule de Noël.
let hitBall = function(){
	for(let i = 0; i<listBall.length ; i++){
		//Test pour voir si le pere noel marche sur une boule de Noël.
		if(((santa.x + 45 >= listBall[i].x) && (santa.y + 75 >= listBall[i].y)) && ((santa.x <= listBall[i].x + 40) && (santa.y <= listBall[i].y + 40))){
			//On déclare la boule comme trouvée, on joue la musique, on supprime la boule et on stoppe les lutins on notant l'instant d'arret.
			listBall[i].found();
			playGrelot();
			deleteBall(listBall[i].x, listBall[i].y);
			isStopped = true;
			lastStop = timeLeft;
		}
	}
};

//Fonction regroupant les fonctions de collision.
let hit = function(){
	hitTree();
	hitElf();
	hitBall();
};

//Si cela fait 15sec que les lutins sont arrêtés alors on les remet en marche.
let changeStop = function(){
	if(isStopped===true && lastStop!=null && Math.abs(lastStop-timeLeft>=15))
		isStopped=false;
};

//Variables correspondant aux images.
let fond  = new Image();
fond.src = "../ressources/neige.jpg";
fond.onload = draw;

let pereNoel = new Image();
pereNoel.src = "../ressources/santa.png";

let sapin = new Image();
sapin.src = "../ressources/sapin.png";

let sapinGift = new Image();
sapinGift.src = "../ressources/sapin_gift.png";

let sapinDecore = new Image();
sapinDecore.src = "../ressources/sapin_decore.png";

let sapinDecoreGift = new Image();
sapinDecoreGift.src = "../ressources/sapin_decore_gift.png";

let elfIm = new Image();
elfIm.src = "../ressources/lutin.png";

let ballIm = new Image();
ballIm.src = "../ressources/ball.png";

let menu = new Image();
menu.src = "../ressources/menu.png";

//Quand une touche du clavier est activée
document.onkeydown = function (e) {
	//Si la partie n'est pas finie.
	if(!gameStopped){		
		if (direction[e.key] !== undefined) {
			//Déplacment et orientation du per Noël en fonction de la touche activée.
			sySanta = direction[e.key];
			if(e.key==="ArrowDown")
				santa.y+=5;
			else if(e.key==="ArrowUp")
				santa.y-=5;
			else if(e.key==="ArrowLeft")
				santa.x-=5;
			else if(e.key==="ArrowRight")
				santa.x+=5;
			if(santa.x>780)
				santa.x=0;
			else if(santa.x<0)
				santa.x=780;
			if(santa.y>580)
				santa.y=0;
			else if(santa.y<0)
				santa.y=580;
			walkSanta();
			ctx.clearRect(0, 0, 800, 600);
			draw();
		}
		else
			return;		
	}
};

//Fonction de victoire
let winGame = function(){
	//S'il reste du temps, que le pere noel n'a plus de cadeaux et qu'il a toujours de l'argent.
	if(timeLeft>0 && santa.gift<=0 && santa.money>0 && !gameStopped){
		//Alors on arrete le jeux, les musiques, on marque la phrase de victoire et enfin on lance la musique de victoire.
		gameStopped = true;
		stopBackGroundMusic();
		stopHohoho();
		stopElfLaugh();
		stopGrelot();
		ctx.font = "50px Verdana";
		ctx.fillStyle = "#48A422";
		ctx.fillText("You won with "+santa.money+" euros !", 100, 300);
		playVictoryMusic();
	}
};

//Fonction de défaite
let stopGame = function(){
	//Si le temps est fini ou que le pere noel n'a plus d'argent.
	if((!gameStopped) && (timeLeft===0 || santa.money===0)){
		//Alors on arrete le jeu, les musiques, on lance la musique de défaite et enfin on lance la musique de défaite.
		gameStopped = true;
		stopBackGroundMusic();
		stopHohoho();
		stopElfLaugh();
		stopGrelot();
		playLooseMusic();
		ctx.font = "50px Verdana";
		ctx.fillStyle = "#C84E4E";
		ctx.fillText("You loose with "+santa.gift+" gifts left !", 50, 300);
	}
};

//Appel des différentes fonctions à intervalles différents
setInterval(decreaseTime,1000);
setInterval(playBackGroundMusic,500);
setInterval(deleteTree,500);
setInterval(createTree,10000);
setInterval(createBall,1000);
setInterval(walkElf, 50);
setInterval(draw,100);
setInterval(hit,200);
setInterval(changeStop,1000);
setInterval(winGame,500);
setInterval(stopGame,1000);


